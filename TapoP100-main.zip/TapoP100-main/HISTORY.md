V0.0.1 - Initial Commit with turn on/off and get device info\
V0.0.2 - Corrected errorCodes.json with MANIFEST.in file\
V0.0.3 - Turned errorCodes.json into a dict to avoid file opening errors\
V0.0.4 - Created README.md\
V0.0.5 - Added K4CZP3R as a contributer\
V0.0.6 - Started Fixing Incorrect Mac and ip address\
V0.0.7 - Fixed Incorrect Mac and ip address\
V0.0.8 - Fixed dot in __init__.py\
V0.0.9 - Added get name function\
V0.0.10 - Added L510E brightness function\
V0.0.11 - Fixed HISTORY.md file not found\
V0.0.12 - \
V0.0.13 - Fix RSA export_key issue\
V0.0.14 - Add P110 Energy Monitoring\
V0.0.15 - Add L530 colour change and white colour\
V0.0.16 - Add timeout for all requests\
V0.0.17 - Both getDeviceInfo and getEnergyUsage now return a json dict \
V0.0.18 - Added 'import ast' to bulb file \
V0.0.19 - Bumped up dependencies \
V0.0.20 - Set device status to 'on' when setting color, color temp or brightness \
V0.0.21 - Set color temperature to 0 before adjusting color \
V0.0.22 - Improve parsing of cookie, thus removing trailing ; \
V0.0.23 - add toggle function to turn on-off the device \
V0.0.24 - \
V0.0.25 - Fixed invalid command 'bdist_wheel' \
V0.1.0 - Fixed majority of -1501 errors, updated README and other small improvements \
V0.1.1 - Create new session in Handshake
V0.1.2 - Better implementation of sessions
